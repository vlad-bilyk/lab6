from task6 import battle_funcs, battle_classes

player1 = battle_classes.Player




print("Game Battleship")

print("Field of second player:")

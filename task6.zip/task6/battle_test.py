from task6 import battle

DATA = battle.read_field('field.txt')
DATA = battle.generate_field()
# letter A B C D E F G H I J
# num 1 - 10
# tup = ("J", 3)
print(DATA)
# print(has_ship(DATA, ("A", 1)))
# print(battle.ship_size(DATA, tup))

# print(battle.field_to_str(DATA))
# field = battle.generate_field()
# print(field)
print(battle.field_to_str(DATA))

print(battle.is_valid(DATA))
for i, y in zip(range(10), range(10)):
    print(i, y)
def has_ship(data, tuple):
    letters = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"]
    indexes = (letters.index(tuple[0]), tuple[1] - 1)
    if data[indexes[1]][indexes[0]] == "*":
        return True
    return False


def ship_size(data, tuple):
    letters = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"]
    size = [0, 0]
    if not has_ship(data, tuple):
        return size
    size = [1, 1]
    try:
        if has_ship(data, (tuple[0], tuple[1] - 1)):
            size[1] += 1
            if has_ship(data, (tuple[0], tuple[1] - 2)):
                size[1] += 1
                if has_ship(data, (tuple[0], tuple[1] - 3)):
                    size[1] += 1
    except IndexError:
        pass
    try:
        if has_ship(data, (tuple[0], tuple[1] + 1)):
            size[1] += 1
            if has_ship(data, (tuple[0], tuple[1] + 2)):
                size[1] += 1
                if has_ship(data, (tuple[0], tuple[1] + 3)):
                    size[1] += 1
    except IndexError:
        pass
    try:
        if has_ship(data, (letters[letters.index(tuple[0])-1], tuple[1])):
            size[1] += 1
            if has_ship(data, (letters[letters.index(tuple[0])-2], tuple[1])):
                size[1] += 1
                if has_ship(data, (letters[letters.index(tuple[0])-3], tuple[1])):
                    size[1] += 1
    except IndexError:
        pass
    try:
        if has_ship(data, (letters[letters.index(tuple[0])+1], tuple[1])):
            size[1] += 1
            if has_ship(data, (letters[letters.index(tuple[0])+2], tuple[1])):
                size[1] += 1
                if has_ship(data, (letters[letters.index(tuple[0])+3], tuple[1])):
                    size[1] += 1
    except IndexError:
        pass
    return size
